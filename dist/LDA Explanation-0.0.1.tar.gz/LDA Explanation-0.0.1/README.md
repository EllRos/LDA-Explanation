This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

<h2>Installation</h2>
pip install git+https://github.com/EllRos/LDA_Explanation.git